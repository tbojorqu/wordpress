<!-- This is a generated file. Please do not edit directly -->

# Maintainers
This file lists how this cookbook project is maintained. When making changes to the system, this
file tells you who needs to review your patch - you need a simple majority of maintainers
for the relevant subsystems to provide a :+1: on your pull request. Additionally, you need
to not receive a veto from a Lieutenant or the Project Lead.

Check out [How Cookbooks are Maintained](https://github.com/chef-cookbooks/community_cookbook_documentation/blob/master/CONTRIBUTING.MD) 
for details on the process and how to become a maintainer or the project lead.

# Project Maintainer
* [Tim Smith](https://github.com/tas50)

# Maintainers
* [Jennifer Davis](https://github.com/sigje)
* [Sean OMeara](https://github.com/someara)
* [Tim Smith](https://github.com/tas50)
* [Thom May](https://github.com/thommay)
